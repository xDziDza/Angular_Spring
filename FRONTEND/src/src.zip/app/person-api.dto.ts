export interface PersonApiDto {
  id?: number;
  firstName?: string;
  familyName?: string;
  age?: number;
  city?: string;
  street?: string;
  postCode?: string;
}
